uniform sampler2D m_Texture;
uniform float m_fx;
uniform float m_fy;
uniform float m_cx;
uniform float m_cy;
uniform float m_K1;
uniform float m_K2;
uniform float m_K3;
uniform float m_K4;
uniform float m_K5;
uniform float m_K6;
uniform float m_P1;
uniform float m_P2;
uniform float m_S1;
uniform float m_S2;
uniform float m_S3;
uniform float m_S4;
uniform float m_Tx;
uniform float m_Ty;

in vec2 texCoord;
out vec4 fragColor;

void main() {

    // Pass from image coordinate with 0,0 at the upper left with X,Y in [0,1] (texture referential)
    // to a centered coordinates with 0,0 at the center and X,Y in [-1,1] (normalized image referential)
    vec2 uv = texCoord * 2.0 - 1.0;
    
    // Compute the distortion radius
    float r2 = dot(uv, uv);
    
    // Distortion computation
    // see https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html
    
    // Radial distortion
    float radialDistortion = (1.0 + m_K1 * r2 + m_K2 * r2 * r2 + m_K3 * r2 * r2 * r2)/(1.0 + m_K4 * r2 + m_K5 * r2 * r2 + m_K6 * r2 * r2 * r2);
    
    // Tangential distortion
    vec2 tangentialDistortion = vec2(
        2.0 * m_P1 * uv.x * uv.y + m_P2 * (r2 + 2.0 * uv.x * uv.x),
        m_P1 * (r2 + 2.0 * uv.y * uv.y) + 2.0 * m_P2 * uv.x * uv.y
    );
    
    // Thin prism distortion
    vec2 thinPrismDistortion = vec2(
        m_S1*r2 + m_S2*r2*r2,
        m_S3*r2 + m_S4*r2*r2
    );
    
    // Global distortion
    vec2 distortedUv = uv / radialDistortion - tangentialDistortion - thinPrismDistortion;
    

    // Pass from centered coordinates with 0,0 at the center and X,Y in [-1,1] (normalized image referential)
    // to image coordinate with 0,0 at the upper left with X,Y in [0,1] (texture referential)
    // Scale the image from center
    distortedUv = distortedUv * 0.5 + 0.5;
    
    // Scale the result
    float scale = abs(m_K1) < 1.0 ? 1.0 - abs(m_K1) : 1.0 / (m_K1 + 1.0);
    distortedUv = (distortedUv * scale) - (scale * 0.5) + 0.5;
    
    fragColor = texture(m_Texture, distortedUv);
}
